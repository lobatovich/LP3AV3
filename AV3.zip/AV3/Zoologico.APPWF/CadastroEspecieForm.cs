﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Zoologico.MODEL;

namespace Zoologico.APPWF
{
    public partial class CadastroEspecieForm : Form
    {

        HttpClient httpClient = new HttpClient();
        public CadastroEspecieForm()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private async void button1_ClickAsync(object sender, EventArgs e)
        {
            Especie especie1 = new Especie();

            especie1.Nome = textBox1.Text;
            especie1.QuantidadeMediaDeComida = int.Parse(textBox2.Text);
            especie1.FrequenciaAlimentarIdeal = int.Parse(textBox3.Text);
            especie1.Curiosidade = (textBox4.Text);

            string c = JsonConvert.SerializeObject(especie1);
            var conteudo = new StringContent(c, System.Text.Encoding.UTF8, "application/json");
            HttpResponseMessage response = await httpClient.PostAsync("http://localhost:5279/swagger/index.html/Especie", conteudo);

            var retorno = await response.Content.ReadAsStringAsync();


            MessageBox.Show("Especie Adiconada com Sucesso\n" + retorno);
            this.Close();
        }
    }
}
