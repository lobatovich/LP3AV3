﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using Zoologico.MODEL;

namespace Zoologico.APPWF
{
    public partial class CadastroDietaForm : Form
    {

        HttpClient httpClient = new HttpClient();
        public CadastroDietaForm()
        {
            InitializeComponent();
        }

        private async void button1_ClickAsync(object sender, EventArgs e)
        {
            Dietum dieta1 = new Dietum();

            dieta1.Modalidade = textBox1.Text;
            dieta1.Quantidade = int.Parse(textBox2.Text);
            dieta1.Frequencia = int.Parse(textBox3.Text);
            

            string c = JsonConvert.SerializeObject(dieta1);
            var conteudo = new StringContent(c, System.Text.Encoding.UTF8, "application/json");
            HttpResponseMessage response = await httpClient.PostAsync("http://localhost:5279/swagger/index.html/Dieta", conteudo);

            var retorno = await response.Content.ReadAsStringAsync();


            MessageBox.Show("Dieta Adiconada com Sucesso\n" + retorno);
            this.Close();
        }
    }
}
