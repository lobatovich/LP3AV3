﻿namespace Zoologico.MODEL;

public partial class Dietum
{
    public int Id { get; set; }

    public string? Modalidade { get; set; }

    public int? Quantidade { get; set; }

    public double? Frequencia { get; set; }

    public virtual ICollection<Animal> Animals { get; } = new List<Animal>();
}
