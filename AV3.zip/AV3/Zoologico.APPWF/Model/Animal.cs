﻿using System;
using System.Collections.Generic;

namespace Zoologico.MODEL;

public partial class Animal
{
    public int Id { get; set; }

    public string? Altura { get; set; }

    public string? Peso { get; set; }

    public int Especie { get; set; }

    public int Dieta { get; set; }

    public double Agressividade { get; set; }

    public virtual Dietum DietaNavigation { get; set; } = null!;

    public virtual Especie EspecieNavigation { get; set; } = null!;
}
