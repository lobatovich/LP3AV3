﻿using System;
using System.Collections.Generic;

namespace Zoologico.MODEL;

public partial class Especie
{
    public int Id { get; set; }

    public string Nome { get; set; } = null!;

    public int? QuantidadeMediaDeComida { get; set; }

    public double? FrequenciaAlimentarIdeal { get; set; }

    public string? Curiosidade { get; set; }

    public virtual ICollection<Animal> Animals { get; } = new List<Animal>();
}
