using Newtonsoft.Json;
using System.Net.Http;
using System.Text.Json.Serialization;
using Zoologico.MODEL;

namespace Zoologico.APPWF
{
    public partial class Form1 : Form
    {
        HttpClient client = new HttpClient();
        public Form1()
        {
            InitializeComponent();
        }

        private async void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            CadastroEspecieForm form = new CadastroEspecieForm();
            form.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CadastroDietaForm form = new CadastroDietaForm();
            form.ShowDialog();
        }

        private async void button3_Click(object sender, EventArgs e)
        {
            var response = await client.GetAsync("http://localhost:5279/swagger/index.html/Animal");
            var conteudo = await response.Content.ReadAsStringAsync();

            List<Animal> animais = JsonConvert.DeserializeObject<List<Animal>>(conteudo);

            dataGridView2.DataSource = animais;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            CadastroAnimalform form = new CadastroAnimalform();
            form.ShowDialog();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private async void button5_Click(object sender, EventArgs e)
        {
            var response = await client.GetAsync("http://localhost:5279/swagger/index.html/Agressividade/" + textBox1.Text);
            var conteudo = await response.Content.ReadAsStringAsync();

            MessageBox.Show(conteudo);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
