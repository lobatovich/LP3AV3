﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zoologico.DAL.DBContext;
using Zoologico.MODEL;

namespace Zoologico.BLL
{
    public class EspecieRepository
    {
        public static void adicionaEspecie(Especie _especie)
        {
            using (var dbContext = new CUsersIgorDesktopCodingFaculdadeLp3Av3Av3ZoologicoDalDatabaseDatabaseMdfContext())
            {
                dbContext.Add(_especie);
                dbContext.SaveChanges();
            }
        }
    }
}
