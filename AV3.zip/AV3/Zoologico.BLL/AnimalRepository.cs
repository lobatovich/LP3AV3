﻿using System.Data.Entity;
using Zoologico.DAL;
using Zoologico.DAL.DBContext;
using Zoologico.MODEL;

namespace Zoologico.BLL

{
    public class AnimalRepository
    {
        public static void adicionaAnimal(Animal _animal)
        {
            using (var dbContext = new CUsersIgorDesktopCodingFaculdadeLp3Av3Av3ZoologicoDalDatabaseDatabaseMdfContext())
            {
                dbContext.Add(_animal);
                dbContext.SaveChanges();
            }
        }

        public static Animal GetAnimalById(int id)
        {
            using (var dbContext = new CUsersIgorDesktopCodingFaculdadeLp3Av3Av3ZoologicoDalDatabaseDatabaseMdfContext())
            {
                var animal = dbContext.Animals.Single(p => p.Id == id);
                return animal;
            }
        }

        public static List<Animal> GetAnimalAll()
        {
            using (var dbContext = new CUsersIgorDesktopCodingFaculdadeLp3Av3Av3ZoologicoDalDatabaseDatabaseMdfContext())
            {
                var listaAnimais = dbContext.Animals.ToList();    
                return listaAnimais;
            }
        }

        public static double GetAgressividadeAnimal(int id)
        {
            using(var dbContext = new CUsersIgorDesktopCodingFaculdadeLp3Av3Av3ZoologicoDalDatabaseDatabaseMdfContext())
            {
                var animal = dbContext.Animals.Single(p => p.Id == id);

                double pesoQuantidade = 0.6;
                double pesoFrequencia = 0.4;

                var diferencaQuantidade = animal.EspecieNavigation.QuantidadeMediaDeComida - animal.DietaNavigation.Quantidade;
                var diferencaFrequencia = animal.EspecieNavigation.FrequenciaAlimentarIdeal - animal.DietaNavigation.Frequencia;
                
                
                var pesoDiferencaQuantidade = pesoQuantidade * diferencaQuantidade;
                var pesoDiferencaFrequencia = pesoFrequencia * diferencaFrequencia;

                
                double agressividade = Math.Abs((double)(pesoDiferencaQuantidade + pesoDiferencaFrequencia));

               
                agressividade = Math.Max(0, Math.Min(100, agressividade));

                
                return (double)agressividade;

            }
        }

        

    }
}
