﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Zoologico.BLL;
using Zoologico.MODEL;

namespace Zoologico.BLLSERVICE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AnimalController : ControllerBase
    {
        [HttpGet(Name = "GetAnimal")]

        public ActionResult<List<Animal>> GetAnimal()
        {
            try
            {
                List<Animal> list = AnimalRepository.GetAnimalAll();

                if(list != null) { return Ok(list); }
                return NotFound();
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost(Name = "AddAnimal")]

        public ActionResult<Animal> AddAnimal(Animal _animal)
        {
            try
            {
                AnimalRepository.adicionaAnimal(_animal);
                return Ok(_animal + " Adicionado com sucesso");

            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

    }

    [Route("api/[controller]")]
    [ApiController]

    public class AgressividadeController : ControllerBase
    {
        [HttpPost(Name = "GetAgressividadeAnimal")]

        public ActionResult<double> GetAgressividadeAnimal(Animal _animal)
        {
            try
            {
                double agressividade = AnimalRepository.GetAgressividadeAnimal(_animal.Id);
                return agressividade;

            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
    }
}
