﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Zoologico.BLL;
using Zoologico.MODEL;

namespace Zoologico.BLLSERVICE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EspecieController : ControllerBase
    {

        [HttpPost(Name = "AddEspecie")]

        public ActionResult<Especie> AddDieta(Especie _especie)
        {
            try
            {
                EspecieRepository.adicionaEspecie(_especie);
                return Ok(_especie + " Adicionada com sucesso");

            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
    }
}
