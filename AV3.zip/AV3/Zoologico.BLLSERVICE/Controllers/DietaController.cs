﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Zoologico.BLL;
using Zoologico.MODEL;

namespace Zoologico.BLLSERVICE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DietaController : ControllerBase
    {

        [HttpPost(Name = "AddDieta")]

        public ActionResult<Dietum> AddAnimal(Dietum _dieta)
        {
            try
            {
                Dietarepository.adicionaDieta(_dieta);
                return Ok(_dieta + " Adicionada com sucesso");

            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
    }
}
