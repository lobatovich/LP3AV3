﻿namespace Zoologico.DAL
{
    public class Class1
    {

    }
}
