﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Zoologico.MODEL;

namespace Zoologico.DAL.DBContext;

public partial class CUsersIgorDesktopCodingFaculdadeLp3Av3Av3ZoologicoDalDatabaseDatabaseMdfContext : DbContext
{
    public CUsersIgorDesktopCodingFaculdadeLp3Av3Av3ZoologicoDalDatabaseDatabaseMdfContext()
    {
    }

    public CUsersIgorDesktopCodingFaculdadeLp3Av3Av3ZoologicoDalDatabaseDatabaseMdfContext(DbContextOptions<CUsersIgorDesktopCodingFaculdadeLp3Av3Av3ZoologicoDalDatabaseDatabaseMdfContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Animal> Animals { get; set; }

    public virtual DbSet<Dietum> Dieta { get; set; }

    public virtual DbSet<Especie> Especies { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\Igor\\Desktop\\Coding\\Faculdade\\LP3\\AV3\\AV3\\Zoologico.DAL\\Database\\Database.mdf;Integrated Security=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Animal>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Animal__3214EC07A2727687");

            entity.ToTable("Animal");

            entity.Property(e => e.Altura)
                .HasMaxLength(10)
                .IsFixedLength();
            entity.Property(e => e.Peso)
                .HasMaxLength(10)
                .IsFixedLength();

            entity.HasOne(d => d.DietaNavigation).WithMany(p => p.Animals)
                .HasForeignKey(d => d.Dieta)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Dieta_ToAnimal");

            entity.HasOne(d => d.EspecieNavigation).WithMany(p => p.Animals)
                .HasForeignKey(d => d.Especie)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Especie_ToAnimal");
        });

        modelBuilder.Entity<Dietum>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Dieta__3214EC07138DD8CD");

            entity.Property(e => e.Modalidade)
                .HasMaxLength(20)
                .IsFixedLength();
        });

        modelBuilder.Entity<Especie>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Especie__3214EC07DA839410");

            entity.ToTable("Especie");

            entity.Property(e => e.Curiosidade)
                .HasMaxLength(300)
                .IsUnicode(false);
            entity.Property(e => e.FrequenciaAlimentarIdeal).HasColumnName("Frequencia_alimentar_ideal");
            entity.Property(e => e.Nome)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.QuantidadeMediaDeComida).HasColumnName("Quantidade_media_de_comida");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
