﻿namespace Zoologico.MODEL
{
    public class Class1
    {

    }
}
